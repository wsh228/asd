function calc(){

    var selectPlec = document.querySelector(".select");
    var plec = selectPlec.options[selectPlec.selectedIndex].value;
    
    var weight = document.querySelector(".waga").value;

    var selectAlco = document.querySelectorAll('.this [name="thisplace[]"]');

    var gramm = document.querySelectorAll('.IleGramm');

    var przekaska =  document.querySelector("#prze");
    var snack = przekaska.options[przekaska.selectedIndex].value;

    var dlugo = document.querySelector("#dlugo").value;

    var past = document.querySelector("#minelo").value;

    var alcoInBlood;
    var allgramm = 0;
    var allDrink = 0;
    var q = 0;
    var w = 0;
    var alcoVyshlo = 0;
    var answer = 0;

    var Vir = 0;
    if(plec === "woman"){
        Vir = 0.6;
    } else if (plec === "man"){
        Vir = 0.7;
    }
    

    // for(let i = 0; i < selectAlco.length;i++){
    //     if(selectAlco[i].value === ""){
    //         alert("You must write!");
    //     }else {
    //         let a = parseInt(selectAlco[i].value);
    //         allDrink = a * 0.06;
    //     }
    // }
    // for(let i = 0; i < gramm.length;i++){
    //     if(gramm[i].value === ""){
    //         alert("You must write!");
    //     } else {
    //         console.log(a = parseInt(gramm[i].value));
    //         allgramm += a;
    //     }
    // }
    
    // if(plec === "" || weight === "" || snack === "" || dlugo === "" || past === ""){
    //     alert("You must write all.");
    //     console.log("Write!!!");
    // } else {
        answer = allgramm / (weight * Vir) - 0.1 * dlugo;// 0.1 - значение понижения концентрации этанола в период времени длительностью в 60 минут.
        
        console.log("Answer "+answer);

        var table = document.createElement('div');
        table.className = 'table';

        table.innerHTML =   '<div class="table">\
                                <div class="tableOne">\
                                </div>\
                                <div class="tableTwo">\
                                </div>\
                            </div>';
        document.getElementById('write').appendChild(table);
    // }


    
}

function add(){
    console.log("Yes");
    var div = document.createElement('div');

    div.className = 'this';

    div.innerHTML = '<select class="select_alco" name="thisplace[]" />\
                            <option value selected>Prosze obrac</option>\
                            <option value="5" >Piwo (5%)</option>\
                            <option value="12" >Wino (12%)</option>\
                            <option value="40" >Wodka (40%)</option>\
                        </select>\
                        <input type="text" class="IleGramm">';
    document.getElementById('this').appendChild(div);
}

